'use strict';

// https://github.com/mikecao/umami

const script = document.createElement('script');
script.setAttribute('async', '');
script.setAttribute('src', 'https://stats.mirotalk.com/script.js');
script.setAttribute('data-website-id', 'd7ae2304-7d9c-4651-b0c8-2f3e0a18224f');
document.head.appendChild(script);
