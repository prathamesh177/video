# MiroTalk C2C - Ngrok

### What is the purpose and functionality of Ngrok?

[https://docs.mirotalk.com/ngrok/ngrok/](https://docs.mirotalk.com/ngrok/ngrok/)

### How to exposing MiroTalk C2C with Ngrok?

[https://docs.mirotalk.com/mirotalk-c2c/ngrok/](https://docs.mirotalk.com/mirotalk-c2c/ngrok/)

---
