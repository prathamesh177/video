# MiroTalk C2C - Self Hosting

### How can I self-host MiroTalk C2C on my own server?

[https://docs.mirotalk.com/mirotalk-c2c/self-hosting/](https://docs.mirotalk.com/mirotalk-c2c/self-hosting/)

---
